# Cellphone Dataset > 2022-08-09 1:53pm
https://universe.roboflow.com/workspace-f5gtr/cellphone-dataset

Provided by a Roboflow user
License: CC BY 4.0

This represents a quick alternative as a subset of the 2017 coco dataset. 
With the choice of only using the cell phone class, annotation file and number of images. 
It contains the following directory tree:

* data/
	* images/ 
		* .jpg
	* labels/ 
		* train.json
		* val.json